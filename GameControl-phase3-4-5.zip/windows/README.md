# GameControl Companion (Windows)

Receives controller input from the Android app and shows it. With the virtual controller option on, it also creates a virtual Xbox 360 controller that games see as a real gamepad.

## Requirements

- Windows 10 or 11, 64-bit
- .NET 8 SDK to build, or the .NET 8 desktop runtime to run a published build
- For the virtual controller: the **ViGEmBus** driver

## ViGEmBus warning

ViGEmBus was archived by its author in November 2023 and gets no more updates. It still works on current Windows builds as far as known, but it may break in future Windows versions. The companion talks to it only through the `IVirtualGamepad` interface, so the driver can be replaced later without changing the networking code.

To install ViGEmBus, use the installer from its last official release. You will need to approve a driver installation prompt, and it requires administrator rights. If the controller option fails, the app shows the error and keeps working in state-only mode.

## Build and test

```bash
dotnet test tests/GameControl.Core.Tests/GameControl.Core.Tests.csproj
dotnet publish src/GameControl.Companion/GameControl.Companion.csproj -c Release -r win-x64 --self-contained false -o out
```

Run `out/GameControl.Companion.exe`. Windows Firewall asks whether to allow it on private networks. Allow it.

## Use

1. Start the companion. It shows a 6-digit pairing code and the PC's LAN address.
2. On the phone, tap the connection pill, enter the address, port 27015, and the code, then tap CONNECT.
3. Optional: tick the virtual controller box to create an Xbox 360 controller.
